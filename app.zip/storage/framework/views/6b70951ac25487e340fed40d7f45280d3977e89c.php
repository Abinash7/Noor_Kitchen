<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="<?php echo e(asset('Icons/invoice.svg')); ?>">

  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- Bootstrap -->
  <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="<?php echo e(asset('admin/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- NProgress -->
  <link href="<?php echo e(('admin/css/nprogress.css')); ?>" rel="stylesheet">

  <!-- Custom Theme Style -->
  <link href="<?php echo e(asset('admin/css/custom.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin/css/style.min.css')); ?>" rel="stylesheet">
</head><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/Admin/header.blade.php ENDPATH**/ ?>