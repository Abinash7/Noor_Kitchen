<?php echo $__env->make('Backend.Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php echo $__env->make('Backend.Staff.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('Backend.Admin.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('Backend.Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Layout/staffdashboard.blade.php ENDPATH**/ ?>