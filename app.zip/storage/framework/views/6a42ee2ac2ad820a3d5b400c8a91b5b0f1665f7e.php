<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt | Billing App</title>
</head>

<body>
    <div class="receipt__heading">
        <h4>Billing App</h4>
        <h6>Dhading, Nepal</h6>
        <p class="receipt__heading pan-no">Pan No: 1234567</p>
    </div>
    <div class="receipt__body">
        <table>
            <thead>
                <tr>
                    <th>S.N</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Discount</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key++); ?></td>

                    <td><?php echo e($info->prod_price); ?></td>
                    <td><?php echo e($info->quantity); ?></td>
                    <td><?php echo e($info->discount); ?></td>
                    <td><?php echo e($info->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/invoice.blade.php ENDPATH**/ ?>