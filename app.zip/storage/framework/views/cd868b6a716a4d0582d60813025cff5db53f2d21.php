<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/backend/receipt.css')); ?>" media="all">
    <link rel="stylesheet" href="<?php echo e(asset('css/backend/no-print.css')); ?>" media="print">
</head>

<body>
    <div id="wrapper">
        <div class="receipt_header">
            <h4 id="shop_name">Noor Kitchen Hygenic Suppliers</h4>
            <h5 id="shop_address">Address: Malekhu, Dhading</h5>
            <h6 id="shop_pan">Vat No: 607095982</h6>
            <p>Invoice Number: <strong><?php echo e($sales->id); ?></strong></p>
            <p>Date: <?php echo e(date('Y-m-d')); ?></p>
            <p>Cotact: +977-9851274786</p>
            <p>Customer: <?php echo e($sales->customer_name); ?></p>
        </div>
        <div class="receipt_body">
            <table class="tb-sale-details">
                <thead>
                    <tr>
                        <th>S.N</th>
                        <th>Name</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$saleDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($saleDetail->product_name); ?></td>
                        <td><?php echo e($saleDetail->quantity); ?></td>
                        <td><?php echo e($saleDetail->product_price); ?></td>
                        <td><?php echo e($saleDetail->product_price * $saleDetail->quantity); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <table class="tb-sale-total">
                <tbody>
                    <tr>
                        <td>Total Amount: Rs. <?php echo e(number_format($sales->total_price,2)); ?></td>
                    </tr>
                    <tr>
                        <td>Amount Received: Rs. <?php echo e(number_format($sales->total_received,2)); ?></td>
                    </tr>
                    <tr>
                        <td>Change Amount: Rs. <?php echo e(number_format($sales->change,2)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="receipt_footer">
            <p>Thankyou !!!</p>
        </div>
        <div id="buttons">
            <a href="/cashier">
                <button class="btn btn-back">Back to Cashier</button>
            </a>
            <button class="btn btn-print" type="button" onclick="window.print() 
            return false;"> Print
            </button>
        </div>
    </div>

</body>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/Cashier/Receipt.blade.php ENDPATH**/ ?>