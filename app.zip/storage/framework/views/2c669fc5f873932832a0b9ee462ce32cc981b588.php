
<?php $__env->startSection('title'); ?>
User | Edit - Noor Kitchen
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>User Page</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">

                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><i class="fa fa-plus"></i> Add User</h2>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo e(session()->get('message')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="container">
                            <form action="<?php echo e(route('users.update',$users->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="form-group">
                                    <label for="fullname">Full Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter your full name" id="full_name" value="<?php echo e($users->full_name); ?>" name="full_name">
                                    <div class="col-7">
                                        <?php if($errors->has('full_name')): ?>
                                        <strong class="alert-danger">
                                            <?php echo e($errors->first('full_name')); ?>

                                        </strong>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Email">Email:</label>
                                    <input type="email" id="email" name="email" class="form-control" value="<?php echo e($users->email); ?>" placeholder="Enter your email">
                                    <div class="col-7">
                                        <?php if($errors->has('email')): ?>
                                        <strong class="alert-danger">
                                            <?php echo e($errors->first('email')); ?>

                                        </strong>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="contact">Contact Number:</label>
                                    <input type="text" class="form-control" placeholder="Enter your contact number" id="contact_number" value="<?php echo e($users->contact_number); ?>" name="contact_number">
                                    <div class="col-7">
                                        <?php if($errors->has('contact_number')): ?>
                                        <strong class="alert-danger">
                                            <?php echo e($errors->first('contact_number')); ?>

                                        </strong>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address:</label>
                                    <input type="text" class="form-control" placeholder="Enter your Address" id="address" value="<?php echo e($users->address); ?>" name="address">
                                    <div class="col-7">
                                        <?php if($errors->has('address')): ?>
                                        <strong class="alert-danger">
                                            <?php echo e($errors->first('address')); ?>

                                        </strong>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="vehicle">Vehicle Number:</label>
                                    <input type="text" class="form-control" placeholder="Enter your full name" id="vehicle_number" value="<?php echo e($users->vehicle_number); ?>" name="vehicle_number">
                                    <div class="col-7">
                                        <?php if($errors->has('vehicle_number')): ?>
                                        <strong class="alert-danger">
                                            <?php echo e($errors->first('vehicle_number')); ?>

                                        </strong>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/User/edit.blade.php ENDPATH**/ ?>