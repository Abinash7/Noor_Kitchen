
<?php $__env->startSection('title'); ?>
User | List - Noor Kitchen
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>User Page</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">

                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Users List</h2>

                        <div class="clearfix"></div>
                    </div>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Add User</a>
                    <div class="x_content table-responsive">
                        <table class="table table-bordered text-center">
                            <thead>
                                <th>S.N</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Contact Number</th>
                                <th>Address</th>
                                <th>Vehicle</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($value->full_name); ?></td>
                                    <td><?php echo e($value->email); ?></td>
                                    <td><?php echo e($value->role); ?></td>
                                    <td><?php echo e($value->contact_number); ?></td>
                                    <td><?php echo e($value->address); ?></td>
                                    <td><?php echo e($value->vehicle_number); ?></td>
                                    <td><a href="<?php echo e(route('users.edit',$value->id)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a></td>
                                    <?php if($value->role != "admin"): ?>
                                    <td>
                                        <form action="<?php echo e(route('users.destroy',$value->id)); ?>" method="POST" onsubmit="return confirm('Are you sure to delete?')">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                    <button class="btn btn-danger" disabled><i class="fa fa-trash"></i></button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center">
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/User/list.blade.php ENDPATH**/ ?>