<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order | Billing App</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>

<body>
    <Section class="container-fluid order">
        <div class="col-lg-8 col-xs-8 order_section">
            <div class="order-heading">
                <p>Billing Machine</p>
            </div>
        </div>
    </Section>
</body>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Order/Index.blade.php ENDPATH**/ ?>