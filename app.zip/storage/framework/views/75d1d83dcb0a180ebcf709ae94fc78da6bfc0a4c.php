<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Home | Billing App</title>
    <style>
        .home {
            margin: 2% 1.5% auto;
        }

        .home .home__heading {
            text-align: center;
            text-transform: uppercase;
            text-decoration: underline;
            font-family: Georgia, 'Times New Roman', Times, serif;
        }

        .home .home__heading .home-title {
            color: #4a47a7;
            font-size: 2rem;
        }

        .home__features {
            width: 100%;
            padding: 5% 10%;
            text-align: center;
            cursor: pointer;
        }

        a {
            text-decoration: none;
            color: #000;
        }

        a:hover {
            color: #012;
        }

        .home__features .home__features-image {
            height: 8rem;
        }

        .home__features .feature-title {
            font-size: 1rem;
        }
    </style>
</head>

<body>


    <!-- As a heading -->
    <nav class="navbar navbar-dark bg-dark">
        <span class="navbar-brand mb-0 h1">Billing App</span>
    </nav>
    <div class="home container">
        <div class="home home__heading">
            <!-- <h3 class="home home__heading home-title">Our Features</h3> -->
        </div>

    </div>
    <div class="home__features row">
        <div class="col-md-4 col-sm-4">
            <a href="/admin/report">
                <img src="<?php echo e(asset('Icons/inventory.svg')); ?>" alt="Features Icon 1" class="home__features home__features-image feature-image-1" />
                <h3 class="home__features feature-title">Management</h3>
            </a>
        </div>
        <div class="col-md-4 col-sm-4">
            <a href="/cashier">
                <img src="<?php echo e(asset('Icons/cashier.svg')); ?>" alt="Features Icon 2" class="home__features home__features-image feature-image-2" />
                <h3 class="home__features feature-title">Cashier</h3>
            </a>
        </div>
        <div class="col-md-4 col-sm-4">
            <a href="/report/list">
                <img src="<?php echo e(asset('Icons/report.svg')); ?>" alt="Features Icon 3" class="home__features home__features-image feature-image-3" />
                <h3 class="home__features feature-title">Report</h3>
            </a>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous">
</script>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/welcome.blade.php ENDPATH**/ ?>