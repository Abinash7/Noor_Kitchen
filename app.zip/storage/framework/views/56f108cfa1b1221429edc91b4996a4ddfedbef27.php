<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashier | Billing App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        #cashier .cashier-info {
            width: 100%;
            text-align: center;
            padding: 2% 5%;
        }

        .form-group {
            margin: 2% auto;
            width: 75%;
        }
    </style>
</head>

<body>
    <section id="cashier">
        <div class="row cashier-info">
            <h2>Sales Information</h2>
            <div class="customer-data col-md-5">
                <h4>Customer Details</h4>
                <form action="">
                    <?php echo csrf_field(); ?>
                    <div class="form-group col-sm-6">
                        <input type="text" id="name" name="name" class="form-control name" placeholder="Enter Customer Name" required>
                    </div>
                    <div class="form-group col-sm-6">
                        <input type="number" id="contact" name="contact" class="form-control contact" placeholder="Enter Customer Number" required>
                    </div>
                </form>
            </div>
            <div class="product-detail col-md-7">
                <h5>Product Detail Section</h5>
            </div>
        </div>

    </section>
</body>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/Cashier/index.blade.php ENDPATH**/ ?>