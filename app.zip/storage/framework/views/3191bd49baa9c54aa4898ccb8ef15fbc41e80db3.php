<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create</title>
</head>

<body>
    <form action="<?php echo e(route('user.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="fullname">Fullname</label>
            <input type="text" placeholder="Fullname" name="full_name" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" placeholder="Email" name="email" required>
        </div>
        <div class="form-group">
            <label for="Password">Password</label>
            <input type="password" placeholder="Password" name="password" required>
        </div>
        <div class="form-group">
            <label for="Address">Address</label>
            <input type="text" placeholder="Address" name="address" required>
        </div>
        <div class="form-group">
            <label for="Contact number">Contact Number</label>
            <input type="number" placeholder="Contact Number" name="contact_number" required>
        </div>
        <div class="form-group">
            <label for="Vehicle">Vehicle Number</label>
            <input type="text" placeholder="Vehicle Number" name="vehicle_number" required>
        </div>
        <div class="form-group">
            <button type="submit">Add</button>
        </div>
</body>

</html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/User/create.blade.php ENDPATH**/ ?>