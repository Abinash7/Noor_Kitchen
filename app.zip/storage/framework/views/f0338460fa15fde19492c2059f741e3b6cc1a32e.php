        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Admin @ <a href="https://noorkitchenhs.com">Noor Kitchen Hygenic Suppliers - </a> <?php echo e(date('Y')); ?>

          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
        </div>
        </div>


        <!-- jQuery -->
        <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
        <!-- Bootstrap -->
        <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
        <!-- FastClick -->
        <script src="<?php echo e(asset('admin/js/fastclick.js')); ?>"></script>
        <!-- NProgress -->
        <script src="<?php echo e(asset('admin/js/nprogress.js')); ?>"></script>

        <!-- Custom Theme Scripts -->
        <script src="<?php echo e(asset('admin/js/custom.min.js')); ?>"></script>
        </body>
        <?php echo $__env->yieldContent('script'); ?>

        </html><?php /**PATH D:\Sameer Hussen dai project\BillingApp\Billing-App\resources\views/Backend/Admin/footer.blade.php ENDPATH**/ ?>