<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\SaleDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function Index()
    {
        $sale = Sale::whereDate('created_at', Carbon::today())
        ->orderBy('created_at','DESC')->paginate(5);
        return view('Backend.Report.Index')->with('sales', $sale);
    }

    public function getReport()
    {
        $sale = Sale::orderBy('id', 'DESC')->get();
        return view('Backend.Report.List')->with('sales', $sale);
    }

    public function getReportByID($id)
    {
        $detail = SaleDetail::with('sale')->where('sale_id', $id)->get();
        // return $detail;
        return view('Backend.Report.show')->with('details', $detail);
    }

    public function individualReport()
    {
        $sale = Sale::whereDate('created_at', Carbon::today())
            ->where('user_id', '=', auth()->user()->id)
            ->orderBy('created_at','DESC')->paginate(5);
        return view('Backend.Report.Individual')->with('sales', $sale);
    }

    public function reportHistory()
    {
        if (isset($_GET['query'])) {
            $search_text = $_GET['query'];
            $sale = Sale::where('vehicle_number', 'LIKE', '%' . $search_text . '%')
            ->orderBy('created_at','DESC')->paginate(5);
            return view('Backend.Report.History')->with('sales', $sale);
        } else {
            $sale = Sale::orderBy('created_at','DESC')->paginate(5);
            return view('Backend.Report.History')->with('sales', $sale);
        }
    }
}
