<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index()
    {
        $client = Client::all();
        return view('Backend.Clients.list')->with('clients', $client);
    }

    public function create()
    {
        return view('Backend.Clients.create');
    }

    public function store(Request $request)
    {
        Client::create($this->clientValidation($request->all()));
        return redirect()->route('client.index')->with('message', 'Client Created Succcessfully !!!');
    }

    public function show(Client $client)
    {
        return $client;
    }

    public function edit(Client $client)
    {
        return $client;
    }

    public function update(Request $request, Client $client)
    {
        return $client->update($this->clientValidation($client->id));
    }

    public function destroy(Client $client)
    {
        return $client->delete();
    }

    private function clientValidation()
    {
        return request()->validate([
            'client_name' => 'required|string',
            'client_address' => 'required|string',
            'contact_number' => 'required|integer'
        ]);
    }
}
