<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AdminSale;
use App\Models\AdminSaleDetails;
use App\Models\Stock;
use App\Models\Category;

class AdminCashierController extends Controller
{
    
    public function index(){
        $category = Category::all();
        return view('Backend.Cashier.AdminCashier')->with('categories', $category);
    }
    public function confirmAdminOrder(Request $request)
    {
        $sale_id = $request->sale_id;
        $saleDetails  = AdminSaleDetails::where('sale_id', $sale_id)->update(['status' => 'confirmed']);
        $html = $this->getAllAdminDetails($sale_id);
        return $html;
    }
    public function orderAdminProduct(Request $request)
    {
        $product = Stock::findorfail($request->product_id);
        // Sales Info
        $sale = AdminSale::where('sale_status', 'unpaid')->first();
        if (!$sale) {
            $sale = new AdminSale();
            $sale->user_id = auth()->user()->id;
            $sale->user_name = auth()->user()->full_name;
            $sale->vehicle_number = auth()->user()->vehicle_number;
            $sale->save();
            $sale_id = $sale->id;
        } else {
            $sale_id = $sale->id;
        }
        //Sales Details
        $sale_detail = new AdminSaleDetails();
        $sale_detail->sale_id = $sale_id;
        $sale_detail->product_id = $product->id;
        $sale_detail->product_name = $product->product_name;
        $sale_detail->product_price = $product->rate;
        $sale_detail->quantity  = $request->quantity;
        $sale_detail->save();

        //Total Price update in sales
        $sale->total_price = $sale->total_price + ($request->quantity * $product->rate);
        $sale->save();

        $html = $this->getAllAdminDetails($sale_id);

        return $html;
    }

    private function getAllAdminDetails($sale_id)
    {
        //List all Sale Details
        $html = '<p>Sale ID: ' . $sale_id . '</p>';
        $saleDetails  = AdminSaleDetails::where('sale_id', $sale_id)->get();
        $html .= '<div class="table-responsive-md" style="overflow-y:scroll; height: 400px; border: 1px solid #343A40;">
        <table class="table table-stripped table-dark">
            <thead>
                <tr>
                    <th scope="col">S.N</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <th scope="col">Total</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>';
        $showBtnPayment = true;
        foreach ($saleDetails as $key => $saleDetail) {
            $decreaseButton = '';
            if ($saleDetail->quantity > 1) {
                $decreaseButton = '<button data-id="' . $saleDetail->id . '" class="btn btn-danger btn-sm btn-decrease-quantity">-</button>';
            }
            $html .= '
                <tr>
                    <td>' . ($key + 1) . '</td>
                    <td>' . $saleDetail->product_name . '</td>
                    <td>' . $decreaseButton . ' ' . $saleDetail->quantity . '<button data-id="' . $saleDetail->id . '" class="btn btn-primary btn-sm btn-increase-quantity">+</button></td>
                    <td>' . $saleDetail->product_price . '</td>
                    <td>' . ($saleDetail->product_price * $saleDetail->quantity) . '</td>';
            if ($saleDetail->status == "notConfirmed") {
                $showBtnPayment = false;
                $html .= '<td><a data-id="' . $saleDetail->id . '" class="btn btn-danger btn-delete-saledetail"><i class="fa fa-trash"></i></a></td>';
            } else {
                $html .= '<td><i class = "fa fa-check-circle"></i></td>';
            }

            $html .= '</tr>';
        }
        $html .= '</tbody></table></div>';

        $sale = AdminSale::findorfail($sale_id);
        $html .= '<hr/>';
        $html .= '<h3>Total Amount : Rs.' . number_format($sale->total_price) . '</h3>';
        $html .= '<hr/>';
        if ($showBtnPayment) {
            $html .= '<div>
            <button data-id=' . $sale_id . ' class="btn btn-success btn-block btn-payment" data-totalAmount="' . $sale->total_price . '" data-toggle="modal" data-target="#exampleModal" style="width:100%;"> Payment </button>
        </div>';
        } else {
            $html .= '<div>
            <button data-id=' . $sale_id . ' class="btn btn-warning btn-block btn-confirm-order" style="width:100%;"> Confirm Order </button>
        </div>';
        }
        return $html;
    }

    public function saveAdminPayment(Request $request)
    {
        $saleID = $request->sale_id;
        $sale = AdminSale::findorfail($saleID);
        $sale->customer_name = $request->customer_name;
        $sale->customer_number = $request->customer_number;
        $sale->total_received = $request->received_amount;
        $sale->change = ($request->received_amount - $sale->total_price);
        $sale->sale_status = "paid";
        $sale->customer_vat = $request->customer_vat;
        $sale->save();
        return "/admin/cashier/adminReceipt/" . $saleID;
    }

    public function deleteDetail(Request $request)
    {
        $saleDetailID = $request->saleDetailID;
        $saleDetail = AdminSaleDetails::findorfail($saleDetailID);
        $deduct_price = ($saleDetail->product_price * $saleDetail->quantity);
        $saleDetail->delete();

        //update price
        $sale = AdminSale::findorfail($saleDetail->sale_id);
        $sale->total_price = $sale->total_price - $deduct_price;
        $sale->save();

        $sale_detail = AdminSaleDetails::where('sale_id', $saleDetail->sale_id)->first();
        if ($saleDetail) {
            $html = $this->getAllAdminDetails($saleDetail->sale_id);
        } else {
            $html = "No record found";
        }
        return $html;
    }

    public function increaseQuantity(Request $request)
    {
        $saleDetailID = $request->saleDetailID;
        $saleDetail = AdminSaleDetails::where('id', $saleDetailID)->first();
        $saleDetail->quantity = $saleDetail->quantity + 1;
        $saleDetail->save();
        //Increase total price
        $sale = AdminSale::findorfail($saleDetail->sale_id);
        $sale->total_price = $sale->total_price + $saleDetail->product_price;
        $sale->save();
        $html = $this->getAllAdminDetails($saleDetail->sale_id);
        return $html;
    }

    public function decreaseQuantity(Request $request)
    {
        $saleDetailID = $request->saleDetailID;
        $saleDetail = AdminSaleDetails::where('id', $saleDetailID)->first();
        $saleDetail->quantity = $saleDetail->quantity - 1;
        $saleDetail->save();
        //Increase total price
        $sale = AdminSale::findorfail($saleDetail->sale_id);
        $sale->total_price = $sale->total_price - $saleDetail->product_price;
        $sale->save();
        $html = $this->getAllAdminDetails($saleDetail->sale_id);
        return $html;
    }

    public function getMenuByCategory($category_id)
    {
        $product = Stock::where('category_id', $category_id)->get();
        $html = '';
        foreach ($product as $prod) {
            $html .= '
            <div class="col-md-3 col-sm-3 text-center">
            <a class="btn btn-outline-secondary btn-menu" data-id="' . $prod->id . '">
            ' . $prod->product_name . '
            </br>
            Rs. ' . number_format($prod->rate) . '
            </br>
             Quantity ' . number_format($prod->quantity) . '
            </a>
            </div> 
            ';
        }
        return $html;
    } 

    public function showReceipt($saleID)
    {
        $sale = AdminSale::findorfail($saleID);
        $saleDetails = AdminSaleDetails::where('sale_id', $saleID)->get();
        return view('Backend.Cashier.AdminReceipt')->with('sales', $sale)->with('saleDetails', $saleDetails);
    }
}
