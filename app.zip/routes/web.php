<?php

use App\Http\Controllers\AdminCashierController;
use App\Http\Controllers\CashierController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\UsersController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('auth.login');
});
//For Staff
Route::prefix('/staff')->middleware('auth', 'revalidate')->group(function () {
    Route::get('/home', function () {
        return view('Backend.Dashboard.staff_dashboard');
    });
    Route::get('/report/individual', [ReportController::class, 'individualReport']);
});

// For Admin
Route::prefix('/admin')->middleware('auth', 'adminauth', 'revalidate')->group(function () {
    Route::get('/home', function () {
        return view('Backend.Dashboard.admin_dashboard');
    });
    Route::resource('/users', UsersController::class);
    Route::resource('/stock', StockController::class);
    Route::get('/stock/quantity/{id}', [StockController::class, 'editStock']);
    Route::put('/stock/quantity/{id}', [StockController::class, 'addStock']);
    Route::resource('/client', ClientController::class);
    Route::resource('/category', CategoryController::class);
    //Reciept Controller Routes
    Route::get('/report', [ReportController::class, 'Index']);
    Route::get('/report/{id}', [ReportController::class, 'getReportByID']);
    Route::get('/report/list', [ReportController::class, 'getReport']);
    Route::get('/history', [ReportController::class, 'reportHistory']); // Report History
    Route::get('/cashier', [CashierController::class, 'adminCashier']);
});


// Route::middleware('auth')->group(function () {
//     return view('welcome');
// });

Route::get('/invoice', function () {
    return view('invoice');
});
Route::resource('/order', OrderController::class);
Route::get('/index', function () {
    return view('welcome');
});

Route::middleware('auth', 'revalidate')->group(function () {
    //Cashier Controller Routes
    Route::get('/cashier', [CashierController::class, 'index']);
    Route::post('/cashier/order', [CashierController::class, 'orderProduct']);
    Route::post('/cashier/confirmOrder', [CashierController::class, 'confirmOrder']);
    Route::post('/cashier/savePayment', [CashierController::class, 'savePayment']);
    Route::get('/admin/cashier/showReceipt/{saleID}', [CashierController::class, 'showReceipt']);
    Route::post('/cashier/deleteDetail', [CashierController::class, 'deleteDetail']);
    Route::post("/cashier/increasequantity", [CashierController::class, 'increaseQuantity']);
    Route::post("/cashier/decreasequantity", [CashierController::class, 'decreaseQuantity']);
    Route::get('/cashier/getMenuByCategory/{category_id}', [CashierController::class, 'getMenuByCategory']);

    //Admin Cashier Routes
    Route::get('/admin/cashier', [AdminCashierController::class, 'index']);
    Route::post('/admin/cashier/confirmOrder', [AdminCashierController::class, 'confirmAdminOrder']);
    Route::post('/admin/cashier/order', [AdminCashierController::class, 'orderAdminProduct']);
    Route::post('/admin/cashier/savePayment', [AdminCashierController::class, 'saveAdminPayment']);
    Route::post('/admin/cashier/deleteDetail', [AdminCashierController::class, 'deleteDetail']);
    Route::post("/admin/cashier/increasequantity", [AdminCashierController::class, 'increaseQuantity']);
    Route::post("/admin/cashier/decreasequantity", [AdminCashierController::class, 'decreaseQuantity']);
    Route::get('/admin/cashier/adminReceipt/{saleID}', [AdminCashierController::class, 'showReceipt']);
});



//Incorrect Url
Route::get('/{path?}', function ($path = null) {
    return view('welcome');
})->where('path', '.*');
