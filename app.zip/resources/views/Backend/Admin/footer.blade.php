        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Admin @ <a href="https://noorkitchenhs.com">Noor Kitchen Hygenic Suppliers - </a> {{date('Y')}}
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
        </div>
        </div>


        <!-- jQuery -->
        <script src="{{asset('admin/js/jquery.min.js')}}"></script>
        <!-- Bootstrap -->
        <script src="{{asset('admin/js/bootstrap.min.js')}}"></script>
        <!-- FastClick -->
        <script src="{{asset('admin/js/fastclick.js')}}"></script>
        <!-- NProgress -->
        <script src="{{asset('admin/js/nprogress.js')}}"></script>

        <!-- Custom Theme Scripts -->
        <script src="{{asset('admin/js/custom.min.js')}}"></script>
        </body>
        @yield('script')

        </html>