@extends('Layout.dashboard')
@section('content')
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Order Page</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">

                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Order List</h2>

                        <div class="clearfix"></div>
                    </div>
                    @if(session()->has('message'))
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        {{session()->get('message')}}
                    </div>
                    @endif
                    <form action="{{route('order.store')}}" method="POST">
                        @csrf
                        <div class="x_content table-responsive">
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>S.N</th>
                                        <th>Product Name</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Discount (%)</th>
                                        <th>Total Amount</th>
                                        <th><a class="btn btn-success btn-sm add"><i class="fa fa-plus"></i></a></th>
                                    </tr>
                                </thead>
                                <tbody class="addMoreProduct">
                                    <tr>
                                        <td>1</td>
                                        <td>
                                            <select name="product_id[]" id="product_id" class="form-control product_id">
                                                <option value="">Select Product</option>
                                                @foreach($product as $products)
                                                <option data-price="{{$products->rate}}" value="{{$products->id}}">{{$products->product_name}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td><input type="number" id="prod_price" name="prod_price[]" class="form-control prod_price"></td>
                                        <td><input type="number" id="quantity" name="quantity[]" class="form-control quantity"></td>
                                        <td><input type="number" id="discount" name="discount[]" class="form-control discount"></td>
                                        <td><input type="number" id="total" name="total[]" class="form-control total"></td>
                                        <td><a class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
        <Section class="receipt">
            <div class="total_calc">
                <p>Total Amount: <b class="total_amount">Rs. 0.00</b></p>
            </div>
            <div class="customer__details">
                <!-- <a href="{{route('client.create')}}" class="btn btn-success"><i class="fa fa-plus"></i> Add Client</a> -->
                <h5>Customer Info</h5>
                <div class="form-group col-sm-6">
                    <select name="customer_id" id="customer_id" class="form-control customer_id">
                        <option value="">Select Customer</option>
                        @foreach($clients as $client)
                        <option data-contact="{{$client->contact_number}}" value="{{$client->id}}">{{$client->client_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group col-sm-6">
                    <input type="number" id="contact" name="contact" class="form-control contact" placeholder="Contact Number">
                </div>
            </div>
            <div class="receipt_amount">
                <h5>Payment Info</h5>
                <div class="form-group">
                    <input type="number" id="received_amount" name="received_amount" class="form-control received_amount" placeholder="Enter Amount Received">
                </div>
                <div class="form-group">
                    <input type="number" readonly id="change_amount" name="change_amount" class="form-control change_amount" placeholder="Change Amount">
                </div>
            </div>
            <button class="btn btn-warning">Save and Print</button>
        </Section>
        </form>

    </div>
</div>
@endsection

@section('script')
<script>
    $('.add').on('click', function() {
        var product = $('.product_id').html();
        var numberofRow = ($('.addMoreProduct tr').length - 0) + 1;
        var tr = '<tr><td class="no">' + numberofRow + '</td>' +
            '<td><select class="form-control product_id" name="product_id[]">' + product + '< /select></td > ' +
            '<td><input type="number" name="prod_price[]" class="form-control prod_price"></td>' +
            '<td><input type="number" name="quantity[]" class="form-control quantity"></td>' +
            '<td><input type="number" name="discount[]" class="form-control discount"></td>' +
            '<td><input type="number" name="total[]" class="form-control total"></td>' +
            '<td><a class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i></a></td>'
        $('.addMoreProduct').append(tr);
    });

    $('.addMoreProduct').delegate('.delete', 'click', function() {
        $(this).parent().parent().remove();
    });

    function TotalAmount() {
        var total = 0;
        $('.total').each(function(i, e) {
            var amount = $(this).val() - 0;
            total += amount;
        });

        $('.total_amount').html(total);
    }

    $('.addMoreProduct').delegate('.product_id', 'change', function() {
        var tr = $(this).parent().parent();
        var price = tr.find('.product_id option:selected').attr('data-price');
        tr.find('.prod_price').val(price);
        var qty = tr.find('.quantity').val() - 0;
        var disc = tr.find('.discount').val() - 0;
        var price = tr.find('.prod_price').val() - 0;
        var total = (qty * price) - ((qty * price * disc) / 100);
        tr.find('.total').val(total);
        TotalAmount();
    });

    $('.addMoreProduct').delegate('.quantity , .discount', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.quantity').val() - 0;
        var disc = tr.find('.discount').val() - 0;
        var price = tr.find('.prod_price').val() - 0;
        var total = (qty * price) - ((qty * price * disc) / 100);
        tr.find('.total').val(total);
        TotalAmount();
    });

    $('.contact').delegate('.customer_id', 'change', function() {
        var contact = $(this).find('.customer_id option:selected').attr('data-contact');
        $(this).find('.contact').val(contact);
    });

    $('.received_amount').keyup(function() {
        var total = $('.total_amount').html();
        var received_amount = $(this).val();
        var ttl = received_amount - total;
        $('.change_amount').val(ttl);
    })
</script>
@endsection