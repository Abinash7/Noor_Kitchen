<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt | Billing App</title>
</head>

<body>
    <div class="receipt__heading">
        <h4>Billing App</h4>
        <h6>Dhading, Nepal</h6>
        <p class="receipt__heading pan-no">Pan No: 1234567</p>
    </div>
    <div class="receipt__body">
        <table>
            <thead>
                <tr>
                    <th>S.N</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Discount</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($infos as $key=>$info)
                <tr>
                    <td>{{$key++}}</td>

                    <td>{{$info->prod_price}}</td>
                    <td>{{$info->quantity}}</td>
                    <td>{{$info->discount}}</td>
                    <td>{{$info->total}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>